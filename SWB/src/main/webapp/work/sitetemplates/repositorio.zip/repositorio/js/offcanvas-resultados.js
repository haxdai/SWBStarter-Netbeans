
        var mediaquery = window.matchMedia("(max-width:767px)"),
        content = document.querySelector(".content");
        function openNav() {
            document.getElementById("offcanvasAbre").style.display = "none";
            document.getElementById("offcanvasCierra").style.display = "inline-block";
            if (mediaquery.matches) {
                    document.getElementById("sidebar").style.width = "45%";
                    document.getElementById("contenido").style.width = "55%";
                } else {
                    document.getElementById("sidebar").style.width = "25%";
                    document.getElementById("contenido").style.width = "75%";
                }
            
            
        }
        function closeNav() {
            document.getElementById("offcanvasAbre").style.display = "inline-block";
            document.getElementById("offcanvasCierra").style.display = "none";
            document.getElementById("sidebar").style.width = "0";
            document.getElementById("contenido").style.width = "100%";
            
        }