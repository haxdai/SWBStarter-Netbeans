        // CARRUSEL 1
        $('#owl-1').owlCarousel({
            loop: true,
            margin: 10,
            nav: false,
            responsive: {
                0: {
                    items: 1
                },
                450: {
                    items: 1
                },
                640: {
                    items: 2
                },
                768: {
                    items: 2
                },
                992: {
                    items: 3
                },
                1200: {
                    items: 3
                }
            }
        });
        var owl = $('.owl-carousel.exh');
        owl.owlCarousel();
        // Go to the next item
        $('.exh.customNextBtn').click(function() {
            owl.trigger('next.owl.carousel');
        })
        // Go to the previous item
        $('.exh.customPrevBtn').click(function() {
            // With optional speed parameter
            // Parameters has to be in square bracket '[]'
            owl.trigger('prev.owl.carousel', [300]);
        })

        // CARRUSEL 2
        $('#owl-2').owlCarousel({
            loop: true,
            margin: 10,
            nav: false,
            responsive: {
                0: {
                    items: 1
                },
                450: {
                    items: 1
                },
                640: {
                    items: 2
                },
                768: {
                    items: 2
                },
                992: {
                    items: 3
                },
                1200: {
                    items: 3
                }
            }
        });
        var owl2 = $('.owl-carousel.bus');
        owl2.owlCarousel();
        // Go to the next item
        $('.bus.customNextBtn').click(function() {
            owl2.trigger('next.owl.carousel');
        })
        // Go to the previous item
        $('.bus.customPrevBtn').click(function() {
            // With optional speed parameter
            // Parameters has to be in square bracket '[]'
            owl2.trigger('prev.owl.carousel', [300]);
        })

        // CARRUSEL 3
        $('#owl-3').owlCarousel({
            loop: true,
            margin: 10,
            nav: false,
            responsive: {
                0: {
                    items: 1
                },
                450: {
                    items: 1
                },
                640: {
                    items: 2
                },
                768: {
                    items: 3
                },
                992: {
                    items: 4
                },
                1200: {
                    items: 5
                }
            }
        });
        var owl3 = $('.owl-carousel.rel');
        owl3.owlCarousel();
        // Go to the next item
        $('.rel.customNextBtn').click(function() {
            owl3.trigger('next.owl.carousel');
        })
        // Go to the previous item
        $('.rel.customPrevBtn').click(function() {
            // With optional speed parameter
            // Parameters has to be in square bracket '[]'
            owl3.trigger('prev.owl.carousel', [300]);
        })
